package com.abbas.oauth;

import java.text.SimpleDateFormat;
import java.time.Duration;
import java.util.Date;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.TimeUnit;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.abbas.oauth.producer.OAuthProducer;



public class Main {
	
    public static void main(String[] args) throws Exception {
        String timestamp = new SimpleDateFormat("yyyyMMddHHmmss").format(new Date());
        String logFile = String.format("logs/output_%s.log", timestamp);
        System.setProperty("org.slf4j.simpleLogger.logFile", logFile);
        System.setProperty("org.slf4j.simpleLogger.defaultLogLevel", "debug");


        
        final long startTime = System.currentTimeMillis();

        Logger log = LoggerFactory.getLogger(Main.class);

        OAuthProducer producer = new OAuthProducer();

        ScheduledExecutorService scheduler = Executors.newScheduledThreadPool(1);
        Runnable task = new Runnable() {

            
            
            
            private int count = 0;
            private final int maxCount = 90 * 60; // 90 minutes in seconds

            
            @Override
            public void run() {
                if (count < maxCount) {
                    try {
                        String message = String.format("Produced java message number %s at %s", count, System.currentTimeMillis());
                        producer.produce("test-topic", "key", message);
                    } catch (Exception exception) {
                        String error = String.format("An error with jaav message number %s: %s", count, exception.getMessage());
                        log.error(error);
                    }

                    long elapsedTimeMillis = System.currentTimeMillis() - startTime;
                    Duration duration = Duration.ofMillis(elapsedTimeMillis);
                    String elapsedTime = String.format("%02d:%02d:%02d", duration.toHours(), duration.toMinutes() % 60, duration.toSeconds() % 60);
                    log.debug(String.format("\nCurrent elapsed time: %s, task executed %s times\n", elapsedTime, count));
                    count++;
                } else {
                    scheduler.shutdown();
                }
            }
        };

        scheduler.scheduleAtFixedRate(task, 0, 15, TimeUnit.SECONDS);
    }
}