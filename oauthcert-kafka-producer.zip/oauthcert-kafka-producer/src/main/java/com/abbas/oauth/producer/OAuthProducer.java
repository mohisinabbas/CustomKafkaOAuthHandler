package com.abbas.oauth.producer;

import java.util.Properties;

import org.apache.kafka.clients.CommonClientConfigs;
import org.apache.kafka.clients.producer.KafkaProducer;
import org.apache.kafka.clients.producer.ProducerConfig;
import org.apache.kafka.clients.producer.ProducerRecord;
import org.apache.kafka.clients.producer.RecordMetadata;
import org.apache.kafka.common.config.SaslConfigs;
import org.apache.kafka.common.security.oauthbearer.OAuthBearerLoginModule;
import org.apache.kafka.common.serialization.StringSerializer;

import com.abbas.oauth.handler.CustomJaasClientOauthLoginCallbackHandler;
import com.abbas.oauth.token.AzureTokenRetriever;
import com.microsoft.aad.msal4j.IAuthenticationResult;

public class OAuthProducer {

    KafkaProducer<String, String> producer;
    
    public OAuthProducer() throws Exception {
        Properties props = new Properties();
        
       // IAuthenticationResult token = AzureTokenRetriever.retrieve();

        props.put(ProducerConfig.BOOTSTRAP_SERVERS_CONFIG, "pkc-12576z.us-west2.gcp.confluent.cloud:9092");
        props.put(CommonClientConfigs.SECURITY_PROTOCOL_CONFIG, "SASL_SSL");
        props.put(SaslConfigs.SASL_MECHANISM, "OAUTHBEARER");
        props.put(SaslConfigs.SASL_OAUTHBEARER_TOKEN_ENDPOINT_URL, "https://login.microsoftonline.com/933d56df-82c3-44b7-99fd-531e163f31e2/oauth2/v2.0/token");
        props.put(SaslConfigs.SASL_LOGIN_CALLBACK_HANDLER_CLASS, CustomJaasClientOauthLoginCallbackHandler.class.getName());
        //System.out.println("token inside oauth producer"+token.accessToken());
        props.put(SaslConfigs.SASL_JAAS_CONFIG, String.join("", OAuthBearerLoginModule.class.getName(), " required ", 
            "oauth.access.token=\"", "ignored", "\" ",
            "oauth.sasl.extension.logicalCluster=\"lkc-p6k9qm\" ", 
            "oauth.sasl.extension.identityPoolId=\"pool-GwvR\";"));

        props.put(ProducerConfig.KEY_SERIALIZER_CLASS_CONFIG, StringSerializer.class.getName());
        props.put(ProducerConfig.VALUE_SERIALIZER_CLASS_CONFIG, StringSerializer.class.getName());
        props.put(ProducerConfig.CLIENT_ID_CONFIG, "OAuthProducer");

        producer = new KafkaProducer<>(props);
    }

    public RecordMetadata produce(String topic, String key, String value) throws Exception {
        ProducerRecord<String, String> record = new ProducerRecord<>(topic, key, value);
        RecordMetadata metadata = producer.send(record).get();
        producer.flush();
        return metadata;
    }

}
