package com.abbas.oauth;

import java.security.PrivateKey;
import java.security.cert.X509Certificate;
import java.util.Collections;
import java.util.concurrent.CompletableFuture;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.fasterxml.jackson.databind.JsonNode;
import com.microsoft.aad.msal4j.ClientCredentialFactory;
import com.microsoft.aad.msal4j.ClientCredentialParameters;
import com.microsoft.aad.msal4j.ConfidentialClientApplication;
import com.microsoft.aad.msal4j.IAuthenticationResult;
import com.microsoft.aad.msal4j.IClientCertificate;
import com.nimbusds.jose.JWSObject;

import io.strimzi.kafka.oauth.common.NimbusPayloadTransformer;
import io.strimzi.kafka.oauth.common.PrincipalExtractor;
import io.strimzi.kafka.oauth.common.TokenInfo;
import io.strimzi.kafka.oauth.validator.ValidationException;
import static io.strimzi.kafka.oauth.common.LogUtil.mask;

public class AzureTokenRetriever {

	private static final Logger log = LoggerFactory.getLogger(AzureTokenRetriever.class);
	private static final NimbusPayloadTransformer TRANSFORMER = new NimbusPayloadTransformer();
	private static final String CLIENT_ID = "65a0e63d-5520-459a-bf9c-a8c2001878ea";
	//private static final String CLIENT_ID = "a52b3586-34dd-4ef4-b38c-4e1e6ecf9cb4";
	private static final String TENANT_ID = "933d56df-82c3-44b7-99fd-531e163f31e2";
	//private static final String TENANT_ID = "34c95ba7-5ec6-4527-bc5e-b33b58104992";
	private static final String AUTHORITY = "https://login.microsoftonline.com/" + TENANT_ID;
	//public static final String SCOPE = "api://65a0e63d-5520-459a-bf9c-a8c2001878ea/.default";
	public static final String SCOPE = "api://"+CLIENT_ID+"/.default";
	private static final String publicCertPath = "/Users/amohammed/eclipse-workspace/oauthcert-kafka-producer-avro/certs/cert2.pem";
	private static final String privateKeyPath = "/Users/amohammed/eclipse-workspace/oauthcert-kafka-producer-avro/certs/key2.pem";
	
	//private static final String publicCertPath = "/Users/amohammed/Downloads/2024-ConfluenctCloud-KafkaAPI-Enablement-QA/2024-ConfluenctCloud-KafkaAPI-Enablement-QA-cert.pem";
	//private static final String privateKeyPath = "/Users/amohammed/Downloads/2024-ConfluenctCloud-KafkaAPI-Enablement-QA/2024-ConfluenctCloud-KafkaAPI-Enablement-QA.pem";
	// private static final String password = "najiya";
	// private String token;

	public static IAuthenticationResult retrieveKafkaToken() throws Exception {
		IAuthenticationResult result =  retrieve();
		log.debug("Kafka Token: {} ", result.accessToken());
		return result;
	}
	
	public static IAuthenticationResult retrieveSRToken() throws Exception {
		IAuthenticationResult result =  retrieve();
		log.debug("SR Token: {} ", result.accessToken());
		return result;
	}
	
	public static IAuthenticationResult retrieve() throws Exception{
		IAuthenticationResult result;
		

			SimplePEMReader pemReader = new SimplePEMReader();

			// EncryptedPEMReader encryptedPrivatekeyPEMReader = new EncryptedPEMReader();

			X509Certificate certificate = pemReader.getCertificate(publicCertPath);

			PrivateKey privateKey = pemReader.getPrivateKey(privateKeyPath);

			// RSA private key is used to sign the client assertion & x509 public
			// certificate used for thumbprint
			IClientCertificate clientCertificate = ClientCredentialFactory.createFromCertificate(privateKey,
					certificate);

			ConfidentialClientApplication app = ConfidentialClientApplication.builder(CLIENT_ID, clientCertificate)
					.authority(AUTHORITY).build();

			ClientCredentialParameters parameters = ClientCredentialParameters.builder(Collections.singleton(SCOPE))
					.build();

			CompletableFuture<IAuthenticationResult> future = app.acquireToken(parameters);

			result = future.get();
			

			return result;
		
	}

	
	
	/*
	 * This is basically the same implementation as
	 * https://github.com/strimzi/strimzi-kafka-oauth/blob/
	 * 89095131aa0f25d9242257cf22166829108b86a3/oauth-common/src/main/java/io/
	 * strimzi/kafka/oauth/common/OAuthAuthenticator.java#L42 but rather than use
	 * the default introspectAccessToken, it will call the retrieve method above to
	 * get a token before converting it to a TokenInfo object
	 */
	public static TokenInfo customLoginWithAccessToken(String token, boolean isJwt,
			PrincipalExtractor principalExtractor) {
		if (log.isDebugEnabled()) {
			log.debug("customLoginWithAccessToken() - pass-through access_token: {}", mask(token));
		}

		if (token == null) {
			throw new IllegalArgumentException("No access token specified");
		}

		if (isJwt) {
			// try introspect token
			try {
				// Implementing a custom introspectAccessToken method to use the Azure APIs to
				// request a new token and then convert it to a TokenInfo object
				return customIntrospectAccessToken(token, principalExtractor);
			} catch (Exception e) {
				log.debug(
						"[IGNORED] Could not parse token as JWT access token. Could not extract scope, subject, and expiry.",
						e);
			}
		}

		return new TokenInfo(token, "undefined", "undefined", null, System.currentTimeMillis(),
				System.currentTimeMillis() + 365 * 24 * 3600000L);
	}

	public static TokenInfo customIntrospectAccessToken(String token, PrincipalExtractor principalExtractor) {

		JWSObject jws;
		try {
			
			// Rather than parse the provided token, get a new one and then pass that
			// jws = JWSObject.parse(token);
			token = retrieveKafkaToken().accessToken();

			jws = JWSObject.parse(token);

		} catch (Exception e) {
			throw new ValidationException("Failed to parse JWT token: " + mask(token));
		}

		try {
			JsonNode parsed = jws.getPayload().toType(TRANSFORMER);

			if (principalExtractor == null) {
				principalExtractor = new PrincipalExtractor();
			}

			String principal = principalExtractor.getPrincipal(parsed);
			if (principal == null) {
				principal = principalExtractor.getSub(parsed);
			}
			return new TokenInfo(parsed, token, principal);

		} catch (Exception e) {
			throw new ValidationException("Failed to read payload from JWT access token", e);
		}
	}
}
