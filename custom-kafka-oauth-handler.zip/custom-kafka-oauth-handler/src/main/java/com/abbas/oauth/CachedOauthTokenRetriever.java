package com.abbas.oauth;

import io.confluent.kafka.schemaregistry.client.SchemaRegistryClientConfig;
import io.confluent.kafka.schemaregistry.client.security.bearerauth.oauth.OauthTokenCache;
import io.confluent.kafka.schemaregistry.client.security.bearerauth.oauth.exceptions.SchemaRegistryOauthTokenRetrieverException;
import org.apache.kafka.common.security.oauthbearer.OAuthBearerToken;
import org.apache.kafka.common.security.oauthbearer.internals.secured.AccessTokenValidator;
import org.apache.kafka.common.security.oauthbearer.internals.secured.ValidateException;

import com.microsoft.aad.msal4j.IAuthenticationResult;

class CachedOauthTokenRetriever {

	  private AccessTokenValidator accessTokenValidator;
	  private OauthTokenCache oauthTokenCache;

	  public void configure(IAuthenticationResult accessTokenRetriever,
	      AccessTokenValidator accessTokenValidator, OauthTokenCache oauthTokenCache) {
	    this.accessTokenValidator = accessTokenValidator;
	    this.oauthTokenCache = oauthTokenCache;

	  }

	  public String getToken() {
	    if (oauthTokenCache.isTokenExpired()) {
	      String token = null;
	      try {
	        token = AzureTokenRetriever.retrieveSRToken().accessToken();
	      } catch (Exception e) {
	        throw new SchemaRegistryOauthTokenRetrieverException(
	            "Failed to Retrieve OAuth Token for Schema Registry", e);
	      }

	      OAuthBearerToken oauthBearerToken;
	      try {
	        oauthBearerToken = accessTokenValidator.validate(token);
	      } catch (ValidateException e) {
	        throw new SchemaRegistryOauthTokenRetrieverException(
	            "OAuth Token for Schema Registry is Invalid", e);
	      }

	      oauthTokenCache.setCurrentToken(oauthBearerToken);
	    }else {
	    	return oauthTokenCache.getCurrentToken().value();
	    }
	    
	    return oauthTokenCache.getCurrentToken().value();
	  }
	  

	}