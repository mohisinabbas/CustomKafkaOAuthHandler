package com.abbas.oauth;

import java.nio.file.Paths;
import java.nio.file.Files;
import java.security.KeyFactory;
import java.security.PrivateKey;

import java.security.spec.PKCS8EncodedKeySpec;
import java.util.Base64;

import javax.crypto.Cipher;
import javax.crypto.EncryptedPrivateKeyInfo;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.PBEKeySpec;

public class EncryptedPEMReader {
	
public PrivateKey getPBEPrivateKey(String privateKeyPath, String password) throws Exception {
        
        // Load the PEM file content
        String pemContent = new String(Files.readAllBytes(Paths.get(privateKeyPath)));
        
        // Remove the PEM header and footer
        pemContent = pemContent.replace("-----BEGIN ENCRYPTED PRIVATE KEY-----", "")
                               .replace("-----END ENCRYPTED PRIVATE KEY-----", "")
                               .replaceAll("\\s", ""); // Remove any extra whitespace

        // Decode the Base64 encoded string
        byte[] keyBytes = Base64.getDecoder().decode(pemContent);
        
        // Parse EncryptedPrivateKeyInfo from the byte array
        EncryptedPrivateKeyInfo encryptedPrivateKeyInfo = new EncryptedPrivateKeyInfo(keyBytes);
        
        // Derive the secret key using password-based encryption (PBE)
        PBEKeySpec pbeKeySpec = new PBEKeySpec(password.toCharArray());
        SecretKeyFactory secretKeyFactory = SecretKeyFactory.getInstance(encryptedPrivateKeyInfo.getAlgName());
        Cipher cipher = Cipher.getInstance(encryptedPrivateKeyInfo.getAlgName());
        cipher.init(Cipher.DECRYPT_MODE, secretKeyFactory.generateSecret(pbeKeySpec), encryptedPrivateKeyInfo.getAlgParameters());

        // Decrypt the private key bytes
        byte[] decryptedKeyBytes = cipher.doFinal(encryptedPrivateKeyInfo.getEncryptedData());

        // Convert the decrypted key bytes into a PrivateKey object
        PKCS8EncodedKeySpec keySpec = new PKCS8EncodedKeySpec(decryptedKeyBytes);
        KeyFactory keyFactory = KeyFactory.getInstance("RSA"); // Assuming RSA encryption algorithm
        PrivateKey privateKey = keyFactory.generatePrivate(keySpec);
        
        System.out.println("Private Key: " + privateKey);
        return privateKey;
    }



    // public PrivateKey getAESPrivateKey(String privateKeyPath, String password) throws Exception{
    //     String b64 = pem.replaceAll("-----(BEGIN|END) ENCRYPTED PRIVATE KEY-----|\r?\n","");
    // byte[] der = Base64.getDecoder().decode(b64);
    
    // // Oracle/OpenJDK param parsing for PBES2 only works in 11.0.1 up 
    // // and currently only for AES-128,256 see JDK-8076999,JDK-8202837
    // EncryptedPrivateKeyInfo eki = new EncryptedPrivateKeyInfo(der);
    // if( !eki.getAlgName().equals("1.2.840.113549.1.5.13") ) 
    //     throw new Exception ("not PBES2"); // or other handling 
    // AlgorithmParameters top = eki.getAlgParameters();
    // // hack to get nonpublic field and class, may break if Java keeps getting stricter
    // Class<?> clazz = top.getClass();
    // Object spi = access(clazz,"paramSpi").get(top);
    // clazz = Class.forName("com.sun.crypto.provider.PBES2Parameters");
    // String spiname = (String) access(clazz,"pbes2AlgorithmName").get(spi);

    // SecretKeyFactory fact = SecretKeyFactory.getInstance(spiname);
    // SecretKey skey = fact.generateSecret(new PBEKeySpec(pw.toCharArray()));
    // Cipher ciph = Cipher.getInstance(spiname); 
    // ciph.init(Cipher.DECRYPT_MODE, skey, eki.getAlgParameters());

    // KeyFactory fac2 = KeyFactory.getInstance("RSA");
    // PrivateKey pkey = fac2.generatePrivate(eki.getKeySpec(ciph));

    // System.out.println ( ((RSAPrivateKey)pkey).getModulus() ); // for test
    //     return pkey;
    // }

    // static Field access (Class<?> clazz, String name) throws Exception {
    //     Field f = clazz.getDeclaredField(name); 
    //     f.setAccessible(true);
    //     return f;
    // }


}
