package com.abbas.oauth;

import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.FileReader;
import java.io.InputStream;
import java.nio.charset.StandardCharsets;
import java.security.KeyFactory;
import java.security.PrivateKey;
import java.security.cert.CertificateFactory;
import java.security.cert.X509Certificate;
import java.security.spec.PKCS8EncodedKeySpec;
import java.util.Base64;

public class SimplePEMReader {
	
	public X509Certificate getCertificate(String publicCertPath) throws Exception {
        // Load the PEM file as an InputStream
        try (InputStream inStream = new FileInputStream(publicCertPath)) {
            // Create a CertificateFactory for X.509 certificates
            CertificateFactory certFactory = CertificateFactory.getInstance("X.509");

            // Generate and return the X509Certificate object
            return (X509Certificate) certFactory.generateCertificate(inStream);
        }
    }

    public PrivateKey getPrivateKey(String privateKeyPath) throws Exception {

        // Read the PEM file as a string
        String pemKey = readPEMFile(privateKeyPath);
        // Remove the PEM header and footer
        pemKey = pemKey.replace("-----BEGIN PRIVATE KEY-----", "")
                       .replace("-----END PRIVATE KEY-----", "")
                       .replaceAll("\\s+", "");  // Remove newlines or spaces
        // Decode Base64 to get the key bytes
        byte[] keyBytes = Base64.getDecoder().decode(pemKey.getBytes(StandardCharsets.UTF_8));
        // Create PKCS8EncodedKeySpec with the key bytes
        PKCS8EncodedKeySpec keySpec = new PKCS8EncodedKeySpec(keyBytes);
        KeyFactory keyFactory = KeyFactory.getInstance("RSA");
        PrivateKey privateKey = keyFactory.generatePrivate(keySpec);

        return privateKey;
    }

    // Helper method to read the PEM file
    private static String readPEMFile(String filePath) throws Exception {
        StringBuilder content = new StringBuilder();
        try (BufferedReader br = new BufferedReader(new FileReader(filePath))) {
            String line;
            while ((line = br.readLine()) != null) {
                content.append(line).append("\n");
            }
        }
        return content.toString();
    }

}
