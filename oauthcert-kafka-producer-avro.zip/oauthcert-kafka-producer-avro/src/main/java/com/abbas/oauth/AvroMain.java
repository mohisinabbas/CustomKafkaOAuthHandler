package com.abbas.oauth;

import java.text.SimpleDateFormat;
import java.time.Duration;
import java.util.Date;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.TimeUnit;

import javax.net.ssl.HostnameVerifier;
import javax.net.ssl.HttpsURLConnection;
import javax.net.ssl.SSLSession;

//import org.slf4j.Logger;
//import org.slf4j.LoggerFactory;

import com.abbas.oauth.producer.OAuthAvroProducer;
import com.abbas.oauth.producer.OAuthProducer;

public class AvroMain {

	public static void main(String[] args) throws Exception {
		String timestamp = new SimpleDateFormat("yyyyMMddHHmmss").format(new Date());
		String logFile = String.format("logs/output_%s.log", timestamp);
		System.setProperty("org.slf4j.simpleLogger.logFile", logFile);
		System.setProperty("org.slf4j.simpleLogger.defaultLogLevel", "debug");
		System.out.println(System.getProperty("javax.net.ssl.trustStore"));

		HttpsURLConnection.setDefaultHostnameVerifier(new HostnameVerifier() {

			@Override
			public boolean verify(String hostname, SSLSession session) {
				return true; // Always return true, effectively disabling hostname verification
			}
		});

		final long startTime = System.currentTimeMillis();

		// Logger log = LoggerFactory.getLogger(AvroMain.class);

		OAuthAvroProducer producer = new OAuthAvroProducer();

		ScheduledExecutorService scheduler = Executors.newScheduledThreadPool(1);
		Runnable task = new Runnable() {

			private int count = 58;
			private final int maxCount = 1 * 60;
			private final int maxCount2 = 2 * 60;
			// 70 minutes in seconds

//            public Employee(java.lang.CharSequence id, java.lang.CharSequence firstName, java.lang.CharSequence lastName, java.lang.Integer age, java.lang.CharSequence email, java.lang.CharSequence zip) {
//                this.id = id;
//                this.firstName = firstName;
//                this.lastName = lastName;
//                this.age = age;
//                this.email = email;
//                this.zip = zip;
//              }

			@Override
			public void run() {
				if (count < maxCount) {
					try {

						producer.produceEmployee("test-2", new Employee("test", "Abbas" + count, "Mohammed" + count,
								count, "abbas@gmail.com", "12345"));
					} catch (Exception exception) {
						String error = String.format("An error with jaav message number %s: %s", count,
								exception.getMessage());
						// log.error(error);
					}

					long elapsedTimeMillis = System.currentTimeMillis() - startTime;
					Duration duration = Duration.ofMillis(elapsedTimeMillis);
					String elapsedTime = String.format("%02d:%02d:%02d", duration.toHours(), duration.toMinutes() % 60,
							duration.toSeconds() % 60);
					// log.debug(String.format("\nCurrent elaspsed time: %s, task executed %s
					// times\n", elapsedTime, count));
					count++;
				} else if (count >= maxCount && count < maxCount2) {
					producer.produceEmployee("avro-testing", new Employee("test", "Abbas" + count, "Mohammed" + count,
							count, "abbas@gmail.com", "12345"));
				} else {
					scheduler.shutdown();
				}
			}
		};

		scheduler.scheduleAtFixedRate(task, 0, 15, TimeUnit.SECONDS);
	}
}