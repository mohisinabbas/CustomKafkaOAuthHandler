package com.abbas.oauth.handler;

import java.net.URL;
import java.util.Map;

import org.apache.kafka.common.security.oauthbearer.internals.secured.AccessTokenValidator;
import org.apache.kafka.common.security.oauthbearer.internals.secured.ConfigurationUtils;
import org.apache.kafka.common.security.oauthbearer.internals.secured.LoginAccessTokenValidator;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.abbas.oauth.token.AzureTokenRetriever;
import com.microsoft.aad.msal4j.IAuthenticationResult;

import io.confluent.kafka.schemaregistry.client.SchemaRegistryClientConfig;
import io.confluent.kafka.schemaregistry.client.security.bearerauth.BearerAuthCredentialProvider;
import io.confluent.kafka.schemaregistry.client.security.bearerauth.oauth.OauthTokenCache;


public class CustomSchemaRegistryOAuthBearerLogin implements BearerAuthCredentialProvider{
	
	private static final Logger LOG = LoggerFactory.getLogger(CustomSchemaRegistryOAuthBearerLogin.class);
	// Schema Registry

	private CachedOauthTokenRetriever tokenRetriever;
	private String targetSchemaRegistry;
	private String targetIdentityPoolId;
	
	@Override
	public void configure(Map<String, ?> configs) {
		LOG.info(targetIdentityPoolId);
		try {
			ConfigurationUtils cu = new ConfigurationUtils(configs);
			targetSchemaRegistry = cu.validateString(SchemaRegistryClientConfig.BEARER_AUTH_LOGICAL_CLUSTER, false);
			targetIdentityPoolId = cu.validateString(SchemaRegistryClientConfig.BEARER_AUTH_IDENTITY_POOL_ID, false);

			tokenRetriever = new CachedOauthTokenRetriever();
			tokenRetriever.configure(getTokenRetriever(), getTokenValidator(configs), getOauthTokenCache(configs));
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	private OauthTokenCache getOauthTokenCache(Map<String, ?> map) {
		short cacheExpiryBufferSeconds = SchemaRegistryClientConfig.getBearerAuthCacheExpiryBufferSeconds(map);
		return new OauthTokenCache(cacheExpiryBufferSeconds);
	}

	@Override
	public String getBearerToken(URL url) {
		return tokenRetriever.getToken();
	}

	private AccessTokenValidator getTokenValidator(Map<String, ?> configs) {
		String scopeClaimName = SchemaRegistryClientConfig.getBearerAuthScopeClaimName(configs);
		String subClaimName = SchemaRegistryClientConfig.getBearerAuthSubClaimName(configs);
		return new LoginAccessTokenValidator(scopeClaimName, subClaimName);
	}

	@Override
	public String getTargetSchemaRegistry() {
		return this.targetSchemaRegistry;
	}

	@Override
	public String getTargetIdentityPoolId() {
		return this.targetIdentityPoolId;
	}

	private IAuthenticationResult getTokenRetriever() throws Exception {
		//System.out.println("I came here for token SR token retrieval"+ tokenRetriever.getToken());
		return AzureTokenRetriever.retrieveSRToken();

	}

}
